#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
学管系统数据库设置脚本
基于文档中的SQL表结构设计
"""

import sqlite3
import os

def create_database():
    """创建SQLite数据库和表结构"""

    # 数据库文件路径
    db_path = 'engineering_management.db'

    # 如果数据库已存在，先删除
    if os.path.exists(db_path):
        os.remove(db_path)

    # 连接数据库
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 创建表的SQL语句
    sql_statements = [
        """
        CREATE TABLE department (
            department_id INTEGER PRIMARY KEY AUTOINCREMENT,
            department_name VARCHAR(100) NOT NULL,
            create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE role (
            role_id INTEGER PRIMARY KEY AUTOINCREMENT,
            role_name VARCHAR(50) -- admin / teacher / student
        );
        """,
        """
        CREATE TABLE teacher (
            teacher_id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_name VARCHAR(50) NOT NULL,
            title VARCHAR(50),
            phone VARCHAR(20),
            department_id INTEGER,
            FOREIGN KEY (department_id) REFERENCES department(department_id)
        );
        """,
        """
        CREATE TABLE student (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name VARCHAR(50) NOT NULL,
            gender VARCHAR(10),
            major VARCHAR(100),
            class_name VARCHAR(50),
            enrollment_year INTEGER,
            department_id INTEGER,
            FOREIGN KEY (department_id) REFERENCES department(department_id)
        );
        """,
        """
        CREATE TABLE course (
            course_id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_name VARCHAR(100) NOT NULL,
            credit INTEGER,
            teacher_id INTEGER,
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
        );
        """,
        """
        CREATE TABLE score (
            score_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            course_id INTEGER,
            score DECIMAL(5,2),
            exam_time TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES student(student_id),
            FOREIGN KEY (course_id) REFERENCES course(course_id)
        );
        """,
        """
        CREATE TABLE thesis (
            thesis_id INTEGER PRIMARY KEY AUTOINCREMENT,
            title VARCHAR(200),
            student_id INTEGER,
            teacher_id INTEGER,
            status VARCHAR(50),
            submit_time TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES student(student_id),
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
        );
        """,
        """
        CREATE TABLE project (
            project_id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_name VARCHAR(200),
            teacher_id INTEGER,
            funding DECIMAL(10,2),
            start_date DATE,
            end_date DATE,
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
        );
        """,
        """
        CREATE TABLE user (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(100) NOT NULL,
            role_id INTEGER,
            related_id INTEGER,
            create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """
    ]

    # 执行SQL语句创建表
    for sql in sql_statements:
        cursor.execute(sql)

    # 提交更改
    conn.commit()

    print(f"数据库已成功创建: {db_path}")
    print("\n创建的表:")
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    for table in tables:
        print(f"  - {table[0]}")

    # 关闭连接
    conn.close()

def insert_sample_data():
    """插入示例数据"""

    conn = sqlite3.connect('engineering_management.db')
    cursor = conn.cursor()

    # 插入示例数据
    sample_data = [
        ("INSERT INTO department (department_name) VALUES ('计算机学院');",),
        ("INSERT INTO department (department_name) VALUES ('机械工程学院');",),
        ("INSERT INTO role (role_name) VALUES ('admin');",),
        ("INSERT INTO role (role_name) VALUES ('teacher');",),
        ("INSERT INTO role (role_name) VALUES ('student');",),
        ("INSERT INTO teacher (teacher_name, title, phone, department_id) VALUES ('张教授', '教授', '13800138001', 1);",),
        ("INSERT INTO student (student_name, gender, major, class_name, enrollment_year, department_id) VALUES ('李同学', '男', '计算机科学与技术', '计科2021-1班', 2021, 1);",),
        ("INSERT INTO course (course_name, credit, teacher_id) VALUES ('数据库原理', 3, 1);",),
    ]

    for sql in sample_data:
        cursor.execute(sql[0])

    conn.commit()
    conn.close()

    print("示例数据已插入")

if __name__ == "__main__":
    print("开始创建学管系统数据库...")
    create_database()
    insert_sample_data()
    print("\n数据库设置完成！")