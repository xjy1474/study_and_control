#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
学管系统数据库设置脚本
基于文档中的SQL表结构设计
"""

import sqlite3
import os

def create_database():
    """创建SQLite数据库和表结构"""

    # 数据库文件路径
    db_path = 'engineering_management.db'

    # 如果数据库已存在，先删除
    if os.path.exists(db_path):
        os.remove(db_path)

    # 连接数据库
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 创建表的SQL语句
    sql_statements = [
        """
        CREATE TABLE department (
            department_id INTEGER PRIMARY KEY AUTOINCREMENT,
            department_name VARCHAR(100) NOT NULL,
            create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE role (
            role_id INTEGER PRIMARY KEY AUTOINCREMENT,
            role_name VARCHAR(50) -- admin / teacher / student
        );
        """,
        """
        CREATE TABLE teacher (
            teacher_id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_name VARCHAR(50) NOT NULL,
            title VARCHAR(50),
            phone VARCHAR(20),
            department_id INTEGER,
            FOREIGN KEY (department_id) REFERENCES department(department_id)
        );
        """,
        """
        CREATE TABLE student (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_name VARCHAR(50) NOT NULL,
            gender VARCHAR(10),
            major VARCHAR(100),
            class_name VARCHAR(50),
            enrollment_year INTEGER,
            department_id INTEGER,
            FOREIGN KEY (department_id) REFERENCES department(department_id)
        );
        """,
        """
        CREATE TABLE course (
            course_id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_name VARCHAR(100) NOT NULL,
            credit INTEGER,
            teacher_id INTEGER,
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
        );
        """,
        """
        CREATE TABLE score (
            score_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            course_id INTEGER,
            score DECIMAL(5,2),
            exam_time TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES student(student_id),
            FOREIGN KEY (course_id) REFERENCES course(course_id)
        );
        """,
        """
        CREATE TABLE thesis (
            thesis_id INTEGER PRIMARY KEY AUTOINCREMENT,
            title VARCHAR(200),
            student_id INTEGER,
            teacher_id INTEGER,
            status VARCHAR(50),
            submit_time TIMESTAMP,
            submitted_by INTEGER,  -- 记录是谁提交的（用户ID）
            FOREIGN KEY (student_id) REFERENCES student(student_id),
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id),
            FOREIGN KEY (submitted_by) REFERENCES user(user_id)
        );
        """,
        """
        CREATE TABLE project (
            project_id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_name VARCHAR(200),
            teacher_id INTEGER,
            funding DECIMAL(10,2),
            start_date DATE,
            end_date DATE,
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
        );
        """,
        """
        CREATE TABLE user (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role_id INTEGER,
            related_id INTEGER,
            email VARCHAR(100),
            is_active BOOLEAN DEFAULT 1,
            last_login TIMESTAMP,
            create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (role_id) REFERENCES role(role_id)
        );
        """,
        """
        CREATE TABLE salary (
            salary_id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id INTEGER,
            base_salary DECIMAL(10,2),
            bonus DECIMAL(10,2),
            deduction DECIMAL(10,2),
            total_salary DECIMAL(10,2),
            month_year DATE,
            payment_date TIMESTAMP,
            status VARCHAR(20) DEFAULT 'pending', -- pending/paid
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
        );
        """,
        """
        CREATE TABLE notification (
            notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
            title VARCHAR(200),
            content TEXT,
            sender_id INTEGER,
            recipient_id INTEGER,
            type VARCHAR(50), -- paper_submitted, salary_paid, system_announcement
            is_read BOOLEAN DEFAULT 0,
            create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES user(user_id),
            FOREIGN KEY (recipient_id) REFERENCES user(user_id)
        );
        """,
        """
        CREATE TABLE teaching_task (
            task_id INTEGER PRIMARY KEY AUTOINCREMENT,
            teacher_id INTEGER,
            course_name VARCHAR(100),
            semester VARCHAR(20),
            student_count INTEGER,
            hours_per_week INTEGER,
            total_hours INTEGER,
            status VARCHAR(20) DEFAULT 'active', -- active/completed
            create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id)
        );
        """,
        """
        CREATE TABLE funding (
            funding_id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_name VARCHAR(200),
            amount DECIMAL(12,2),
            category VARCHAR(50), -- research/teaching/equipment/other
            applicant_id INTEGER,
            approver_id INTEGER,
            status VARCHAR(20) DEFAULT 'pending', -- pending/approved/rejected
            application_date DATE,
            approval_date DATE,
            description TEXT,
            FOREIGN KEY (applicant_id) REFERENCES user(user_id),
            FOREIGN KEY (approver_id) REFERENCES user(user_id)
        );
        """,
        """
        CREATE TABLE award (
            award_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            award_name VARCHAR(200),
            level VARCHAR(20), -- first/second/third
            category VARCHAR(100), -- academic/competition/scholarship/other
            awarding_body VARCHAR(200),
            award_date DATE,
            description TEXT,
            FOREIGN KEY (student_id) REFERENCES student(student_id)
        );
        """
    ]

    # 执行SQL语句创建表
    for sql in sql_statements:
        cursor.execute(sql)

    # 提交更改
    conn.commit()

    print(f"数据库已成功创建: {db_path}")
    print("\n创建的表:")
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    for table in tables:
        print(f"  - {table[0]}")

    # 关闭连接
    conn.close()

def insert_sample_data():
    """插入示例数据"""

    conn = sqlite3.connect('engineering_management.db')
    cursor = conn.cursor()

    # 插入示例数据
    sample_data = [
        ("INSERT INTO department (department_name) VALUES ('计算机学院');",),
        ("INSERT INTO department (department_name) VALUES ('机械工程学院');",),
        ("INSERT INTO role (role_name) VALUES ('admin');",),
        ("INSERT INTO role (role_name) VALUES ('teacher');",),
        ("INSERT INTO role (role_name) VALUES ('student');",),
        ("INSERT INTO teacher (teacher_name, title, phone, department_id) VALUES ('张教授', '教授', '13800138001', 1);",),
        ("INSERT INTO teacher (teacher_name, title, phone, department_id) VALUES ('王老师', '副教授', '13800138002', 1);",),
        ("INSERT INTO student (student_name, gender, major, class_name, enrollment_year, department_id) VALUES ('李同学', '男', '计算机科学与技术', '计科2021-1班', 2021, 1);",),
        ("INSERT INTO student (student_name, gender, major, class_name, enrollment_year, department_id) VALUES ('王小红', '女', '软件工程', '软工2021-1班', 2021, 1);",),
        ("INSERT INTO course (course_name, credit, teacher_id) VALUES ('数据库原理', 3, 1);",),
        ("INSERT INTO course (course_name, credit, teacher_id) VALUES ('软件工程', 4, 2);",),
        # 默认用户账户 (密码: admin123, teacher123, student123)
        ("INSERT INTO user (username, password_hash, role_id, related_id, email) VALUES ('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RXo0vrSQe', 1, NULL, 'admin@school.edu');",),
        ("INSERT INTO user (username, password_hash, role_id, related_id, email) VALUES ('teacher1', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RXo0vrSQe', 2, 1, 'teacher1@school.edu');",),
        ("INSERT INTO user (username, password_hash, role_id, related_id, email) VALUES ('student1', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RXo0vrSQe', 3, 1, 'student1@school.edu');",),
    ]

    for sql in sample_data:
        cursor.execute(sql[0])

    conn.commit()
    conn.close()

    print("示例数据已插入")

if __name__ == "__main__":
    print("开始创建学管系统数据库...")
    create_database()
    insert_sample_data()
    print("\n数据库设置完成！")