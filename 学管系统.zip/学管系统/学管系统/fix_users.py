#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
修复用户密码哈希
"""

import sqlite3
import bcrypt

def fix_user_passwords():
    """修复用户密码"""
    conn = sqlite3.connect('engineering_management.db')
    cursor = conn.cursor()

    # 生成正确的密码哈希
    admin_hash = bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    teacher_hash = bcrypt.hashpw('teacher123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    student_hash = bcrypt.hashpw('student123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    # 更新用户密码
    cursor.execute("UPDATE user SET password_hash = ? WHERE username = 'admin'", (admin_hash,))
    cursor.execute("UPDATE user SET password_hash = ? WHERE username = 'teacher1'", (teacher_hash,))
    cursor.execute("UPDATE user SET password_hash = ? WHERE username = 'student1'", (student_hash,))

    conn.commit()
    conn.close()

    print("用户密码已修复！")
    print("现在可以使用以下账户登录：")
    print("- 管理员: admin / admin123")
    print("- 教师: teacher1 / teacher123")
    print("- 学生: student1 / student123")

if __name__ == "__main__":
    fix_user_passwords()