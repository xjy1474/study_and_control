#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
学管系统 - Web应用
基于Flask框架的简单管理系统
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import sqlite3
import os
import hashlib
import bcrypt
from functools import wraps
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this to a secure secret key
DATABASE = 'engineering_management.db'

def get_db_connection():
    """获取数据库连接"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password):
    """Hash a password using bcrypt"""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(password, hashed):
    """Verify a password against its hash"""
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def login_required(f):
    """Decorator to require login for routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

def role_required(required_role):
    """Decorator to require specific role"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return jsonify({'error': 'Authentication required'}), 401

            conn = get_db_connection()
            user = conn.execute('''
                SELECT u.*, r.role_name
                FROM user u
                JOIN role r ON u.role_id = r.role_id
                WHERE u.user_id = ?
            ''', (session['user_id'],)).fetchone()
            conn.close()

            if not user or user['role_name'] != required_role:
                return jsonify({'error': 'Insufficient permissions'}), 403

            return f(*args, **kwargs)
        return decorated_function
    return decorator

def get_current_user():
    """Get current logged in user info"""
    if 'user_id' not in session:
        return None

    conn = get_db_connection()
    user = conn.execute('''
        SELECT u.*, r.role_name
        FROM user u
        JOIN role r ON u.role_id = r.role_id
        WHERE u.user_id = ?
    ''', (session['user_id'],)).fetchone()
    conn.close()

    return dict(user) if user else None

@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

@app.route('/login')
def login_page():
    """登录页面"""
    return render_template('login.html')

@app.route('/api/departments')
def get_departments():
    """获取所有院系"""
    conn = get_db_connection()
    departments = conn.execute('SELECT * FROM department').fetchall()
    conn.close()

    return jsonify([dict(dept) for dept in departments])

@app.route('/api/teachers')
def get_teachers():
    """获取所有教师"""
    conn = get_db_connection()
    teachers = conn.execute('''
        SELECT t.*, d.department_name
        FROM teacher t
        LEFT JOIN department d ON t.department_id = d.department_id
    ''').fetchall()
    conn.close()

    return jsonify([dict(teacher) for teacher in teachers])

@app.route('/api/students')
def get_students():
    """获取所有学生"""
    conn = get_db_connection()
    students = conn.execute('''
        SELECT s.*, d.department_name
        FROM student s
        LEFT JOIN department d ON s.department_id = d.department_id
    ''').fetchall()
    conn.close()

    return jsonify([dict(student) for student in students])

@app.route('/api/courses')
def get_courses():
    """获取所有课程"""
    conn = get_db_connection()
    courses = conn.execute('''
        SELECT c.*, t.teacher_name
        FROM course c
        LEFT JOIN teacher t ON c.teacher_id = t.teacher_id
    ''').fetchall()
    conn.close()

    return jsonify([dict(course) for course in courses])

@app.route('/add_teacher', methods=['POST'])
def add_teacher():
    """添加教师"""
    data = request.json
    conn = get_db_connection()

    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO teacher (teacher_name, title, phone, department_id)
        VALUES (?, ?, ?, ?)
    ''', (data['name'], data['title'], data['phone'], data['department_id']))

    conn.commit()

    # 创建系统通知
    create_notification(
        title='新教师添加',
        content=f'新教师 {data["name"]} 已被添加到系统中',
        recipient_id=None,  # None 表示系统通知，所有管理员都能看到
        sender_id=current_user['user_id'] if 'user_id' in locals() else None,
        notification_type='teacher_added'
    )

    conn.close()

    return jsonify({'success': True, 'message': '教师添加成功'})

@app.route('/add_student', methods=['POST'])
def add_student():
    """添加学生"""
    data = request.json
    conn = get_db_connection()

    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO student (student_name, gender, major, class_name, enrollment_year, department_id)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (data['name'], data['gender'], data['major'], data['class_name'], data['enrollment_year'], data['department_id']))

    conn.commit()

    # 创建系统通知
    create_notification(
        title='新学生添加',
        content=f'新学生 {data["name"]} 已被添加到系统中',
        recipient_id=None,
        sender_id=current_user['user_id'] if 'user_id' in locals() else None,
        notification_type='student_added'
    )

    conn.close()

    return jsonify({'success': True, 'message': '学生添加成功'})

# Authentication routes
@app.route('/login', methods=['POST'])
def login():
    """用户登录"""
    data = request.json
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'success': False, 'message': '用户名和密码不能为空'})

    conn = get_db_connection()
    user = conn.execute('''
        SELECT u.*, r.role_name
        FROM user u
        JOIN role r ON u.role_id = r.role_id
        WHERE u.username = ? AND u.is_active = 1
    ''', (username,)).fetchone()
    conn.close()

    if user and verify_password(password, user['password_hash']):
        session['user_id'] = user['user_id']
        session['username'] = user['username']
        session['role'] = user['role_name']

        # Update last login time
        conn = get_db_connection()
        conn.execute('UPDATE user SET last_login = ? WHERE user_id = ?',
                    (datetime.now(), user['user_id']))
        conn.commit()
        conn.close()

        return jsonify({
            'success': True,
            'message': '登录成功',
            'user': {
                'user_id': user['user_id'],
                'username': user['username'],
                'role': user['role_name'],
                'email': user['email']
            }
        })
    else:
        return jsonify({'success': False, 'message': '用户名或密码错误'})

@app.route('/logout')
def logout():
    """用户登出"""
    session.clear()
    return jsonify({'success': True, 'message': '登出成功'})

@app.route('/api/current_user')
def get_current_user_api():
    """获取当前用户信息"""
    user = get_current_user()
    if user:
        return jsonify({'success': True, 'user': user})
    else:
        return jsonify({'success': False, 'message': '未登录'})

@app.route('/api/papers')
def get_papers():
    """获取论文列表"""
    current_user = get_current_user()
    if not current_user:
        return jsonify({'error': 'Authentication required'}), 401

    conn = get_db_connection()

    # 根据用户角色返回不同的论文数据
    if current_user['role_name'] == 'admin':
        # 管理员可以看到所有论文
        papers = conn.execute('''
            SELECT t.*, s.student_name, te.teacher_name as advisor_name,
                   su.student_name as submitter_student_name,
                   tu.teacher_name as submitter_teacher_name
            FROM thesis t
            LEFT JOIN student s ON t.student_id = s.student_id
            LEFT JOIN teacher te ON t.teacher_id = te.teacher_id
            LEFT JOIN user u ON t.submitted_by = u.user_id
            LEFT JOIN student su ON u.related_id = su.student_id AND u.role_id = 3
            LEFT JOIN teacher tu ON u.related_id = tu.teacher_id AND u.role_id = 2
            ORDER BY t.submit_time DESC
        ''').fetchall()
    elif current_user['role_name'] == 'teacher':
        # 老师可以看到所有论文
        papers = conn.execute('''
            SELECT t.*, s.student_name, te.teacher_name as advisor_name,
                   su.student_name as submitter_student_name,
                   tu.teacher_name as submitter_teacher_name
            FROM thesis t
            LEFT JOIN student s ON t.student_id = s.student_id
            LEFT JOIN teacher te ON t.teacher_id = te.teacher_id
            LEFT JOIN user u ON t.submitted_by = u.user_id
            LEFT JOIN student su ON u.related_id = su.student_id AND u.role_id = 3
            LEFT JOIN teacher tu ON u.related_id = tu.teacher_id AND u.role_id = 2
            ORDER BY t.submit_time DESC
        ''').fetchall()
    else:
        # 学生只能看到自己的论文
        papers = conn.execute('''
            SELECT t.*, s.student_name, te.teacher_name as advisor_name
            FROM thesis t
            LEFT JOIN student s ON t.student_id = s.student_id
            LEFT JOIN teacher te ON t.teacher_id = te.teacher_id
            WHERE t.student_id = ?
            ORDER BY t.submit_time DESC
        ''', (current_user['related_id'],)).fetchall()

    conn.close()
    return jsonify([dict(paper) for paper in papers])

@app.route('/api/papers/search')
@login_required
def search_papers():
    """搜索论文"""
    current_user = get_current_user()
    query = request.args.get('q', '')
    status = request.args.get('status', '')
    teacher_id = request.args.get('teacher_id', '')
    student_id = request.args.get('student_id', '')

    conn = get_db_connection()

    # 基础查询
    base_query = '''
        SELECT t.*, s.student_name, te.teacher_name as advisor_name,
               su.student_name as submitter_student_name,
               tu.teacher_name as submitter_teacher_name
        FROM thesis t
        LEFT JOIN student s ON t.student_id = s.student_id
        LEFT JOIN teacher te ON t.teacher_id = te.teacher_id
        LEFT JOIN user u ON t.submitted_by = u.user_id
        LEFT JOIN student su ON u.related_id = su.student_id AND u.role_id = 3
        LEFT JOIN teacher tu ON u.related_id = tu.teacher_id AND u.role_id = 2
    '''

    # 权限过滤条件
    if current_user['role_name'] == 'admin':
        where_clause = "WHERE 1=1"
        params = []
    elif current_user['role_name'] == 'teacher':
        where_clause = '''WHERE (t.teacher_id = ? OR su.department_id =
                    (SELECT department_id FROM teacher WHERE teacher_id = ?))'''
        params = [current_user['related_id'], current_user['related_id']]
    else:
        where_clause = "WHERE t.student_id = ?"
        params = [current_user['related_id']]

    # 添加搜索条件
    if query:
        where_clause += " AND t.title LIKE ?"
        params.append(f'%{query}%')

    if status:
        where_clause += " AND t.status = ?"
        params.append(status)

    if teacher_id and current_user['role_name'] == 'admin':
        where_clause += " AND t.teacher_id = ?"
        params.append(teacher_id)

    if student_id and current_user['role_name'] == 'admin':
        where_clause += " AND t.student_id = ?"
        params.append(student_id)

    sql = f"{base_query} {where_clause} ORDER BY t.submit_time DESC"
    papers = conn.execute(sql, params).fetchall()
    conn.close()

    return jsonify([dict(paper) for paper in papers])

@app.route('/api/salary')
@role_required('admin')
def get_salary():
    """获取工资信息 (仅管理员)"""
    conn = get_db_connection()
    salaries = conn.execute('''
        SELECT s.*, t.teacher_name, t.title
        FROM salary s
        LEFT JOIN teacher t ON s.teacher_id = t.teacher_id
        ORDER BY s.month_year DESC
    ''').fetchall()
    conn.close()

    return jsonify([dict(salary) for salary in salaries])

@app.route('/api/statistics')
@login_required
def get_statistics():
    """获取系统统计数据"""
    current_user = get_current_user()
    conn = get_db_connection()

    stats = {}

    # 基础统计（所有用户都能看到）
    stats['total_teachers'] = conn.execute('SELECT COUNT(*) as count FROM teacher').fetchone()['count']
    stats['total_students'] = conn.execute('SELECT COUNT(*) as count FROM student').fetchone()['count']
    stats['total_courses'] = conn.execute('SELECT COUNT(*) as count FROM course').fetchone()['count']
    stats['total_departments'] = conn.execute('SELECT COUNT(*) as count FROM department').fetchone()['count']

    # 论文统计
    if current_user['role_name'] == 'admin':
        stats['total_papers'] = conn.execute('SELECT COUNT(*) as count FROM thesis').fetchone()['count']
        stats['papers_by_status'] = dict(conn.execute('SELECT status, COUNT(*) as count FROM thesis GROUP BY status').fetchall())
        stats['papers_by_department'] = dict(conn.execute('''
            SELECT d.department_name, COUNT(*) as count
            FROM thesis t
            LEFT JOIN student s ON t.student_id = s.student_id
            LEFT JOIN department d ON s.department_id = d.department_id
            GROUP BY d.department_name
        ''').fetchall())
    elif current_user['role_name'] == 'teacher':
        teacher_id = current_user['related_id']
        stats['my_papers'] = conn.execute('SELECT COUNT(*) as count FROM thesis WHERE teacher_id = ?', (teacher_id,)).fetchone()['count']
        stats['department_papers'] = conn.execute('''
            SELECT COUNT(*) as count FROM thesis t
            LEFT JOIN student s ON t.student_id = s.student_id
            WHERE s.department_id = (SELECT department_id FROM teacher WHERE teacher_id = ?)
        ''', (teacher_id,)).fetchone()['count']
    else:
        student_id = current_user['related_id']
        stats['my_papers'] = conn.execute('SELECT COUNT(*) as count FROM thesis WHERE student_id = ?', (student_id,)).fetchone()['count']

    # 工资统计（仅管理员）
    if current_user['role_name'] == 'admin':
        stats['total_salary'] = conn.execute('SELECT SUM(total_salary) as total FROM salary').fetchone()['total'] or 0
        stats['avg_salary'] = conn.execute('SELECT AVG(total_salary) as avg FROM salary').fetchone()['avg'] or 0

    conn.close()
    return jsonify(stats)

@app.route('/api/export/<data_type>')
@role_required('admin')
def export_data(data_type):
    """数据导出功能"""
    conn = get_db_connection()

    if data_type == 'students':
        data = conn.execute('SELECT * FROM student').fetchall()
        headers = ['学号', '姓名', '性别', '专业', '班级', '入学年份']
        rows = [[s['student_id'], s['student_name'], s['gender'], s['major'], s['class_name'], s['enrollment_year']] for s in data]
    elif data_type == 'teachers':
        data = conn.execute('SELECT * FROM teacher').fetchall()
        headers = ['工号', '姓名', '职称', '电话']
        rows = [[t['teacher_id'], t['teacher_name'], t['title'], t['phone']] for t in data]
    elif data_type == 'papers':
        data = conn.execute('''
            SELECT t.*, s.student_name, te.teacher_name as advisor_name
            FROM thesis t
            LEFT JOIN student s ON t.student_id = s.student_id
            LEFT JOIN teacher te ON t.teacher_id = te.teacher_id
        ''').fetchall()
        headers = ['论文ID', '标题', '学生', '指导教师', '状态', '提交时间']
        rows = [[p['thesis_id'], p['title'], p['student_name'], p['advisor_name'], p['status'], p['submit_time']] for p in data]
    else:
        conn.close()
        return jsonify({'error': '不支持的数据类型'}), 400

    conn.close()

    # 生成CSV格式数据
    import csv
    import io

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(headers)
    writer.writerows(rows)

    return jsonify({
        'success': True,
        'data': output.getvalue(),
        'filename': f'{data_type}_{datetime.now().strftime("%Y%m%d")}.csv'
    })

@app.route('/add_paper', methods=['POST'])
@login_required
def add_paper():
    """添加论文"""
    current_user = get_current_user()
    data = request.json

    conn = get_db_connection()
    cursor = conn.cursor()

    # 根据角色设置论文关系
    student_id = data.get('student_id')
    teacher_id = data.get('teacher_id')

    # 验证权限
    if current_user['role_name'] == 'student':
        student_id = current_user['related_id']
    elif current_user['role_name'] == 'teacher':
        teacher_id = current_user['related_id']

    cursor.execute('''
        INSERT INTO thesis (title, student_id, teacher_id, status, submit_time, submitted_by)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (data['title'], student_id, teacher_id, data.get('status', 'draft'), datetime.now(), current_user['user_id']))

    conn.commit()

    # 创建系统通知
    create_notification(
        title='新论文提交',
        content=f'新论文《{data["title"]}》已提交到系统中',
        recipient_id=None,
        sender_id=current_user['user_id'],
        notification_type='paper_submitted'
    )

    conn.close()

    return jsonify({'success': True, 'message': '论文添加成功'})

@app.route('/add_salary', methods=['POST'])
@role_required('admin')
def add_salary():
    """添加工资记录"""
    data = request.json
    conn = get_db_connection()

    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO salary (teacher_id, base_salary, bonus, deduction, total_salary, month_year, payment_date, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (data['teacher_id'], data['base_salary'], data['bonus'], data['deduction'],
          data['total_salary'], data['month_year'], datetime.now(), data.get('status', 'pending')))

    conn.commit()

    # 创建系统通知
    teacher_name = conn.execute('SELECT teacher_name FROM teacher WHERE teacher_id = ?', (data['teacher_id'],)).fetchone()
    create_notification(
        title='新工资记录',
        content=f'已为教师 {teacher_name[0]} 添加工资记录，总额：¥{data["total_salary"]}',
        recipient_id=None,
        sender_id=current_user['user_id'],
        notification_type='salary_added'
    )

    conn.close()

    return jsonify({'success': True, 'message': '工资记录添加成功'})

# 消息通知系统
@app.route('/api/notifications')
@login_required
def get_notifications():
    """获取用户通知"""
    current_user = get_current_user()
    conn = get_db_connection()

    # 管理员可以看到所有系统通知，其他用户只能看到发给自己的通知
    if current_user['role_name'] == 'admin':
        notifications = conn.execute('''
            SELECT n.*, u1.username as sender_name, u2.username as recipient_name
            FROM notification n
            LEFT JOIN user u1 ON n.sender_id = u1.user_id
            LEFT JOIN user u2 ON n.recipient_id = u2.user_id
            ORDER BY n.create_time DESC
            LIMIT 100
        ''').fetchall()
    else:
        notifications = conn.execute('''
            SELECT n.*, u1.username as sender_name, u2.username as recipient_name
            FROM notification n
            LEFT JOIN user u1 ON n.sender_id = u1.user_id
            LEFT JOIN user u2 ON n.recipient_id = u2.user_id
            WHERE n.recipient_id = ?
            ORDER BY n.create_time DESC
            LIMIT 50
        ''', (current_user['user_id'],)).fetchall()

    conn.close()
    return jsonify([dict(notification) for notification in notifications])

@app.route('/api/notifications/unread-count')
@login_required
def get_unread_count():
    """获取未读通知数量"""
    current_user = get_current_user()
    conn = get_db_connection()

    if current_user['role_name'] == 'admin':
        # 管理员看到所有未读的系统通知
        count = conn.execute('''
            SELECT COUNT(*) as count
            FROM notification
            WHERE is_read = 0
        ''').fetchone()['count']
    else:
        # 其他用户只看到发给自己的未读通知
        count = conn.execute('''
            SELECT COUNT(*) as count
            FROM notification
            WHERE recipient_id = ? AND is_read = 0
        ''', (current_user['user_id'],)).fetchone()['count']

    conn.close()
    return jsonify({'count': count})

@app.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def mark_notification_read():
    """标记通知为已读"""
    current_user = get_current_user()
    notification_id = request.json.get('notification_id')

    conn = get_db_connection()
    conn.execute('''
        UPDATE notification
        SET is_read = 1
        WHERE notification_id = ? AND (recipient_id = ? OR recipient_id IS NULL)
    ''', (notification_id, current_user['user_id']))
    conn.commit()
    conn.close()

    return jsonify({'success': True})

def create_notification(title, content, recipient_id, sender_id, notification_type):
    """创建通知的内部函数"""
    conn = get_db_connection()
    conn.execute('''
        INSERT INTO notification (title, content, sender_id, recipient_id, type)
        VALUES (?, ?, ?, ?, ?)
    ''', (title, content, sender_id, recipient_id, notification_type))
    conn.commit()
    conn.close()

# 教学任务管理（教师端）
@app.route('/api/teaching-tasks')
@login_required
def get_teaching_tasks():
    """获取教学任务"""
    current_user = get_current_user()
    conn = get_db_connection()

    if current_user['role_name'] == 'teacher':
        tasks = conn.execute('''
            SELECT * FROM teaching_task
            WHERE teacher_id = ?
            ORDER BY create_time DESC
        ''', (current_user['related_id'],)).fetchall()
    else:
        # 管理员可以看到所有教学任务
        tasks = conn.execute('SELECT * FROM teaching_task ORDER BY create_time DESC').fetchall()

    conn.close()
    return jsonify([dict(task) for task in tasks])

@app.route('/add_teaching_task', methods=['POST'])
@login_required
def add_teaching_task():
    """添加教学任务"""
    current_user = get_current_user()
    data = request.json

    conn = get_db_connection()
    cursor = conn.cursor()

    # 如果是教师，自动设置teacher_id
    teacher_id = data.get('teacher_id', current_user['related_id'] if current_user['role_name'] == 'teacher' else None)

    cursor.execute('''
        INSERT INTO teaching_task (teacher_id, course_name, semester, student_count, hours_per_week, total_hours, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (teacher_id, data['course_name'], data['semester'], data['student_count'],
          data['hours_per_week'], data['total_hours'], data.get('status', 'active')))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': '教学任务添加成功'})

# 经费管理（管理员端）
@app.route('/api/funding')
@role_required('admin')
def get_funding():
    """获取经费申请"""
    conn = get_db_connection()
    funding = conn.execute('''
        SELECT f.*, u1.username as applicant_name, u2.username as approver_name
        FROM funding f
        LEFT JOIN user u1 ON f.applicant_id = u1.user_id
        LEFT JOIN user u2 ON f.approver_id = u2.user_id
        ORDER BY f.application_date DESC
    ''').fetchall()
    conn.close()

    return jsonify([dict(item) for item in funding])

@app.route('/add_funding', methods=['POST'])
@login_required
def add_funding():
    """添加经费申请"""
    current_user = get_current_user()
    data = request.json

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO funding (project_name, amount, category, applicant_id, description, application_date, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (data['project_name'], data['amount'], data['category'], current_user['user_id'],
          data['description'], datetime.now().date(), 'pending'))

    conn.commit()
    conn.close()

    # 创建通知
    create_notification(
        title='新经费申请',
        content=f'新的经费申请：{data["project_name"]}，金额：¥{data["amount"]}',
        recipient_id=None,
        sender_id=current_user['user_id'],
        notification_type='funding_applied'
    )

    return jsonify({'success': True, 'message': '经费申请提交成功'})

@app.route('/approve_funding', methods=['POST'])
@role_required('admin')
def approve_funding():
    """审批经费申请"""
    current_user = get_current_user()
    data = request.json

    conn = get_db_connection()
    conn.execute('''
        UPDATE funding
        SET status = ?, approver_id = ?, approval_date = ?
        WHERE funding_id = ?
    ''', (data['status'], current_user['user_id'], datetime.now().date(), data['funding_id']))
    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': '经费申请已处理'})

# 获奖管理（学生端）
@app.route('/api/awards')
@login_required
def get_awards():
    """获取获奖信息"""
    current_user = get_current_user()
    conn = get_db_connection()

    if current_user['role_name'] == 'student':
        awards = conn.execute('''
            SELECT * FROM award
            WHERE student_id = ?
            ORDER BY award_date DESC
        ''', (current_user['related_id'],)).fetchall()
    else:
        # 教师和管理员可以看到所有获奖信息
        awards = conn.execute('SELECT * FROM award ORDER BY award_date DESC').fetchall()

    conn.close()
    return jsonify([dict(award) for award in awards])

@app.route('/add_award', methods=['POST'])
@login_required
def add_award():
    """添加获奖信息"""
    current_user = get_current_user()
    data = request.json

    conn = get_db_connection()
    cursor = conn.cursor()

    # 如果是学生，自动设置student_id
    student_id = data.get('student_id', current_user['related_id'] if current_user['role_name'] == 'student' else None)

    cursor.execute('''
        INSERT INTO award (student_id, award_name, level, category, awarding_body, award_date, description)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (student_id, data['award_name'], data['level'], data['category'],
          data['awarding_body'], data['award_date'], data['description']))

    conn.commit()
    conn.close()

    # 创建通知
    student_name = conn.execute('SELECT student_name FROM student WHERE student_id = ?', (student_id,)).fetchone()
    create_notification(
        title='学生获奖',
        content=f'学生 {student_name[0]} 获得{data["level"]}等奖：{data["award_name"]}',
        recipient_id=None,
        sender_id=current_user['user_id'],
        notification_type='award_received'
    )

    return jsonify({'success': True, 'message': '获奖信息添加成功'})

if __name__ == '__main__':
    # 检查数据库是否存在，如果不存在则创建
    if not os.path.exists(DATABASE):
        print("数据库不存在，请先运行 database_setup.py")
        exit(1)

    app.run(debug=True, host='127.0.0.1', port=5000)