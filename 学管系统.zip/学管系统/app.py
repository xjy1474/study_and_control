#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
学管系统 - Web应用
基于Flask框架的简单管理系统
"""

from flask import Flask, render_template, request, jsonify
import sqlite3
import os

app = Flask(__name__)
DATABASE = 'engineering_management.db'

def get_db_connection():
    """获取数据库连接"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    """首页"""
    return render_template('index.html')

@app.route('/api/departments')
def get_departments():
    """获取所有院系"""
    conn = get_db_connection()
    departments = conn.execute('SELECT * FROM department').fetchall()
    conn.close()

    return jsonify([dict(dept) for dept in departments])

@app.route('/api/teachers')
def get_teachers():
    """获取所有教师"""
    conn = get_db_connection()
    teachers = conn.execute('''
        SELECT t.*, d.department_name
        FROM teacher t
        LEFT JOIN department d ON t.department_id = d.department_id
    ''').fetchall()
    conn.close()

    return jsonify([dict(teacher) for teacher in teachers])

@app.route('/api/students')
def get_students():
    """获取所有学生"""
    conn = get_db_connection()
    students = conn.execute('''
        SELECT s.*, d.department_name
        FROM student s
        LEFT JOIN department d ON s.department_id = d.department_id
    ''').fetchall()
    conn.close()

    return jsonify([dict(student) for student in students])

@app.route('/api/courses')
def get_courses():
    """获取所有课程"""
    conn = get_db_connection()
    courses = conn.execute('''
        SELECT c.*, t.teacher_name
        FROM course c
        LEFT JOIN teacher t ON c.teacher_id = t.teacher_id
    ''').fetchall()
    conn.close()

    return jsonify([dict(course) for course in courses])

@app.route('/add_teacher', methods=['POST'])
def add_teacher():
    """添加教师"""
    data = request.json
    conn = get_db_connection()

    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO teacher (teacher_name, title, phone, department_id)
        VALUES (?, ?, ?, ?)
    ''', (data['name'], data['title'], data['phone'], data['department_id']))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': '教师添加成功'})

@app.route('/add_student', methods=['POST'])
def add_student():
    """添加学生"""
    data = request.json
    conn = get_db_connection()

    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO student (student_name, gender, major, class_name, enrollment_year, department_id)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (data['name'], data['gender'], data['major'], data['class_name'], data['enrollment_year'], data['department_id']))

    conn.commit()
    conn.close()

    return jsonify({'success': True, 'message': '学生添加成功'})

if __name__ == '__main__':
    # 检查数据库是否存在，如果不存在则创建
    if not os.path.exists(DATABASE):
        print("数据库不存在，请先运行 database_setup.py")
        exit(1)

    app.run(debug=True, host='127.0.0.1', port=5000)