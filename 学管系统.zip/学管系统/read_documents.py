import docx
import PyPDF2

def read_docx(file_path):
    try:
        doc = docx.Document(file_path)
        content = []
        for paragraph in doc.paragraphs:
            content.append(paragraph.text)
        return "\n".join(content)
    except Exception as e:
        return f"Error reading {file_path}: {str(e)}"

def read_pdf(file_path):
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            content = []
            for page in pdf_reader.pages:
                content.append(page.extract_text())
            return "\n".join(content)
    except Exception as e:
        return f"Error reading {file_path}: {str(e)}"

# 读取所有文档
files = [
    "./数据库生成代码.docx",
    "./调研记录-工程设计与管理.pdf",
    "./(2022-0224)概要文档.doc",
    "./(2022-0224)需求分析终稿.doc"
]

for file_path in files:
    print(f"\n=== 读取文件: {file_path} ===")
    if file_path.endswith('.docx'):
        content = read_docx(file_path)
    elif file_path.endswith('.pdf'):
        content = read_pdf(file_path)
    else:
        print(f"不支持的文件格式: {file_path}")
        continue

    print(content.encode('utf-8').decode('utf-8', errors='ignore'))
    print("\n" + "="*50)