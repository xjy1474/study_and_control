#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
创建带正确密码的用户
"""

import sqlite3
import bcrypt

def create_users_with_correct_passwords():
    """创建带有正确密码哈希的用户"""
    conn = sqlite3.connect('engineering_management.db')
    cursor = conn.cursor()

    # 删除现有用户
    cursor.execute("DELETE FROM user")

    # 生成正确的密码哈希
    admin_hash = bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    teacher_hash = bcrypt.hashpw('teacher123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    student_hash = bcrypt.hashpw('student123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

    print(f"Admin hash: {admin_hash}")
    print(f"Teacher hash: {teacher_hash}")
    print(f"Student hash: {student_hash}")

    # 插入新用户
    cursor.execute(
        "INSERT INTO user (username, password_hash, role_id, related_id, email) VALUES (?, ?, ?, ?, ?)",
        ('admin', admin_hash, 1, None, 'admin@school.edu')
    )
    cursor.execute(
        "INSERT INTO user (username, password_hash, role_id, related_id, email) VALUES (?, ?, ?, ?, ?)",
        ('teacher1', teacher_hash, 2, 1, 'teacher1@school.edu')
    )
    cursor.execute(
        "INSERT INTO user (username, password_hash, role_id, related_id, email) VALUES (?, ?, ?, ?, ?)",
        ('student1', student_hash, 3, 1, 'student1@school.edu')
    )

    conn.commit()
    conn.close()

    print("用户创建成功！")
    print("登录信息：")
    print("   管理员: admin / admin123")
    print("   教师: teacher1 / teacher123")
    print("   学生: student1 / student123")

if __name__ == "__main__":
    create_users_with_correct_passwords()