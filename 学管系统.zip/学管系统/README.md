# 🎓 学管系统

基于文档中的数据库设计，这是一个完整的学管系统的Web应用。

## 📁 项目结构

```
学管系统/
├── database_setup.py      # 数据库初始化脚本
├── app.py                 # Flask Web应用主程序
├── templates/
│   └── index.html         # 前端页面
├── requirements.txt       # Python依赖包
└── README.md             # 项目说明
```

## 🚀 运行步骤

### 第一步：安装依赖

打开命令行，进入项目目录：

```bash
cd 学管系统
```

安装所需的Python包：

```bash
pip install -r requirements.txt
```

### 第二步：创建数据库

运行数据库初始化脚本：

```bash
python database_setup.py
```

这将创建一个名为 `engineering_management.db` 的SQLite数据库文件，包含以下表：
- department (院系表)
- role (角色表) 
- teacher (教师表)
- student (学生表)
- course (课程表)
- score (成绩表)
- thesis (论文表)
- project (项目表)
- user (用户表)

### 第三步：启动Web应用

```bash
python app.py
```

启动成功后，你会看到类似这样的输出：
```
开始创建学管系统数据库...
数据库已成功创建: engineering_management.db

创建的表:
  - department
  - role
  - teacher
  - student
  - course
  - score
  - thesis
  - project
  - user
示例数据已插入

数据库设置完成！
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://127.0.0.1:5000
```

### 第四步：访问系统

打开浏览器，访问：

```
http://127.0.0.1:5000
```

## 💻 功能特性

### 仪表板
- 显示系统概览统计信息
- 教师、学生、课程、院系的总数统计

### 教师管理
- 查看所有教师信息
- 添加新教师
- 显示教师所属院系

### 学生管理  
- 查看所有学生信息
- 添加新学生
- 显示学生详细信息（专业、班级、入学年份等）

### 课程管理
- 查看所有课程信息
- 显示授课教师

### 院系管理
- 查看所有院系信息

## 🛠️ 技术栈

- **后端**: Python + Flask
- **数据库**: SQLite
- **前端**: HTML + CSS + JavaScript
- **UI**: 原生CSS样式，响应式设计

## 📝 数据库表结构

系统包含9个主要数据表：

1. **department** - 院系信息
2. **teacher** - 教师信息，关联院系
3. **student** - 学生信息，关联院系
4. **course** - 课程信息，关联教师
5. **score** - 成绩信息，关联学生和课程
6. **thesis** - 论文信息，关联学生和教师
7. **project** - 项目信息，关联教师
8. **user** - 用户账户信息
9. **role** - 用户角色（admin/teacher/student）

## 🔧 故障排除

### 如果遇到数据库连接问题：
1. 确保已运行 `database_setup.py` 创建数据库
2. 检查当前目录是否存在 `engineering_management.db` 文件

### 如果端口被占用：
修改 `app.py` 中的端口号：
```python
app.run(debug=True, host='127.0.0.1', port=5001)  # 改为其他端口
```

### 如果缺少依赖包：
```bash
pip install flask
```

## 🎯 后续扩展建议

1. **用户认证** - 添加登录/登出功能
2. **权限管理** - 基于角色的访问控制
3. **数据导入导出** - Excel/CSV格式支持
4. **搜索功能** - 快速查找师生信息
5. **统计报表** - 生成各类统计图表
6. **移动端适配** - 响应式手机界面

---

💡 **提示**: 这是一个基础版本，可以根据实际需求进行功能扩展和界面美化。